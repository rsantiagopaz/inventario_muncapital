-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-05-2020 a las 02:59:08
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inventario_muncapital`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bien`
--

CREATE TABLE `bien` (
  `id_bien` int(11) NOT NULL,
  `id_hoja_cargo_item` int(11) DEFAULT NULL,
  `imagen` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_serie` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `codigo_qr` text COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_cargo`
--

CREATE TABLE `hoja_cargo` (
  `id_hoja_cargo` int(11) NOT NULL,
  `id_uni_presu` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `fecha_carga` datetime DEFAULT NULL,
  `fecha_verific` datetime DEFAULT NULL,
  `asunto_cargo` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `asunto_asociado` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_factura` date DEFAULT NULL,
  `nro_factura` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario_carga` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario_verific` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` enum('C','V') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_cargo_item`
--

CREATE TABLE `hoja_cargo_item` (
  `id_hoja_cargo_item` int(11) NOT NULL,
  `id_hoja_cargo` int(11) DEFAULT NULL,
  `id_tipo_bien` int(11) DEFAULT NULL,
  `descrip` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cantidad` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_movimiento`
--

CREATE TABLE `hoja_movimiento` (
  `id_hoja_movimiento` int(11) NOT NULL,
  `id_uni_presu` int(11) DEFAULT NULL,
  `fecha_movimiento` datetime DEFAULT NULL,
  `tipo_movimiento` enum('A','M','B') COLLATE utf8_spanish_ci DEFAULT NULL,
  `asunto_autoriza` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observa` text COLLATE utf8_spanish_ci DEFAULT NULL,
  `tipo_acto_adm` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nro_acto_adm` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario_movimiento` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_movimiento_item`
--

CREATE TABLE `hoja_movimiento_item` (
  `id_hoja_movimiento_item` int(11) NOT NULL,
  `id_hoja_movimiento` int(11) DEFAULT NULL,
  `id_bien` int(11) DEFAULT NULL,
  `guarda_custodia` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `paramet`
--

CREATE TABLE `paramet` (
  `id_paramet` int(11) NOT NULL,
  `json` text COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `paramet`
--

INSERT INTO `paramet` (`id_paramet`, `json`) VALUES
(1, '{\"parametros_etiqueta\":{\"filas\":13,\"margen_sup\":12,\"margen_izq\":5,\"ancho_etiq\":40,\"alto_etiq\":21,\"barra_cantidad\":3,\"barra_pad_sup\":1.5,\"barra_pad_izq\":5,\"chk_barra_ancho\":false,\"barra_ancho\":0,\"chk_barra_alto\":true,\"barra_alto\":18,\"qr_cantidad\":2,\"qr_pad_sup\":1.5,\"qr_pad_izq\":5,\"chk_qr_ancho\":false,\"qr_ancho\":0,\"chk_qr_alto\":true,\"qr_alto\":18}}');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuit` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `razon_social` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `categoria_iva` varchar(2) COLLATE utf8_spanish_ci DEFAULT NULL,
  `contacto` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`id_proveedor`, `descrip`, `cuit`, `razon_social`, `categoria_iva`, `contacto`) VALUES
(1, 'Lo Bruno Automotores', '20103405060', NULL, NULL, NULL),
(2, 'Gemsa', '9080706050', NULL, NULL, NULL),
(3, 'HC Mecanica General de Campos Peregrina Maria Soledad', '27-22618110-0', NULL, NULL, NULL),
(4, 'Grandes Emprendedores de Rodrigo Gonzalo Coronel', '23-38735664-9', NULL, NULL, NULL),
(5, 'Neumaticos y Lubricantes Santiago - Nuevos Emprendimientos SRL', '30-71461661-3', NULL, NULL, NULL),
(6, 'Ralenti de Suarez Maria Graciela', '27-14054959-8', NULL, NULL, NULL),
(7, 'Maxi-Car taller de Mecanica Integral de Nancy del Carmen juarez', '23-26692906-4', NULL, NULL, NULL),
(8, 'JMR de Romero Jesus Matias', '20-32055046-8', NULL, NULL, NULL),
(9, 'TORNERIA MECANICA de Gustavo Daniel de Pablo', '20-28900562-6', NULL, NULL, NULL),
(10, 'David Neumaticos', '33-69978850-9', 'David Neumatico', '01', NULL),
(11, 'Las Malvinas', 'Este es el cuit', 'Las Malvinas RS', '01', NULL),
(12, 'Le Mans Automotores', NULL, 'Le Mans Automotores', '01', NULL),
(14, '3D Computación', NULL, '3D Computación', '01', NULL),
(15, 'LubriNor', '30715583271', 'Lubrinor S.R.L.', '01', NULL),
(16, 'Taller Medina', '20126352787', 'Roberto O. Medina', '01', NULL),
(17, 'Paz Mauro Javier', '20254279693', 'Paz Mauro Javier', '06', NULL),
(18, 'MCO', '20181024942', 'Parma Luis Ariel', '01', NULL),
(19, 'Macroffice', '20230419087', 'Villalba Carlos Andres Edberto', '01', NULL),
(20, 'Santiago Informatica', '30714042293', 'TISE S.C.', '01', NULL),
(21, 'Dr Soft', '20273913573', 'Diego Olivera', '06', NULL),
(22, 'INTEGRAL', '27234107483', 'Natalia Herrera', '06', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_alta`
--

CREATE TABLE `tipo_alta` (
  `id_tipo_alta` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_alta`
--

INSERT INTO `tipo_alta` (`id_tipo_alta`, `descrip`) VALUES
(1, 'Por compra'),
(2, 'Por donación');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_baja`
--

CREATE TABLE `tipo_baja` (
  `id_tipo_baja` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_baja`
--

INSERT INTO `tipo_baja` (`id_tipo_baja`, `descrip`) VALUES
(1, 'Desuso'),
(2, 'Pérdida'),
(3, 'Robo'),
(4, 'Rotura');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_bien`
--

CREATE TABLE `tipo_bien` (
  `id_tipo_bien` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_bien`
--

INSERT INTO `tipo_bien` (`id_tipo_bien`, `descrip`) VALUES
(1, '123-Vehículos y Otros'),
(2, '100-Muebles'),
(3, '155-Computadora - Otros Informática'),
(4, '148-Elementos de Cocina, matafuego'),
(5, '102-Electrodomesticos'),
(6, '110-Herramientas de taller'),
(7, '113-Audio y Tv'),
(8, '109-Herramientas Generales'),
(9, '104-Maquinaria'),
(10, '122-Accesorios en gral.'),
(11, '119-Elementos de laboratorio'),
(12, '135-Libros');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `uni_presu`
--

CREATE TABLE `uni_presu` (
  `id_uni_presu` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `jefe_unidad` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `uni_presu`
--

INSERT INTO `uni_presu` (`id_uni_presu`, `descrip`, `jefe_unidad`) VALUES
(1, '304-DIRECCION DEL NIÑO Y EL ADOLESCENTE', NULL),
(2, 'ARBOLADO URBANO', NULL),
(3, '511/0-CENTRO OPERATIVO Nº 0', NULL),
(4, '511/1-CENTRO OPERATIVO Nº 1', NULL),
(5, '511/2-CENTRO OPERATIVO Nº 2', NULL),
(6, '511/3-CENTRO OPERATIVO Nº 3', NULL),
(7, '511/4-CENTRO OPERATIVO Nº 4', NULL),
(8, '511/5-CENTRO OPERATIVO Nº 5', NULL),
(9, '510-DIRECCION DE CALIDAD DE VIDA', NULL),
(10, '509-SUB DIRECCION DE CEMENTERIO', NULL),
(11, '702-SUB DIRECCION DE CEREMONIAL Y PROTOCOLO', NULL),
(12, 'CIC CAMPO CONTRERAS', NULL),
(13, '701-SECRETARIA DE COORDINACION DE GABINETE', NULL),
(14, '309-SUB DIRECCION DE DEFENSA CIVIL', NULL),
(15, '901-DEFENSORIA DEL PUEBLO', 'Ramón Santiago Paz'),
(16, '504-DIRECCIÓN DE ELECTRICIDAD Y ALUMBRADO PUBLICO', NULL),
(17, '801-TRIBUNAL DE CUENTAS', NULL),
(18, '404-DIRECCIÓN DE RENTAS', NULL),
(19, '508-DIRECCION DE TRANSITO Y TRANSPORTE', NULL),
(20, '511/7-CENTRO OPERATIVO Nº 7', NULL),
(21, '511/8-CENTRO OPERATIVO Nº 8', NULL),
(22, '513-SUB DIRECCION DE CONTROL Y GESTION URBANA', NULL),
(23, '707-DIRECCION DE PERSONAL Y RECONOCIMIENTO MEDICO', NULL),
(24, '307-DIRECCION DE EDUCACION', NULL),
(25, '506-DIRECCIÓN DE ESTUDIOS Y PROYECTOS', NULL),
(26, '302-DIRECCION DE SALUD', NULL),
(27, 'AREA DE HABILITACIONES', NULL),
(28, '704-AREA DE PERSONERIA JURIDICA Y RELACIONES DELIBERANTES', NULL),
(29, '201-INTENDENCIA', 'Carlos Filippa'),
(30, '703-SUB DIRECCION DE PRENSA', NULL),
(31, '502-DIRECCION DE OBRAS PUBLICAS Y MANTENIMIENTO', NULL),
(32, '312-SUB SECRETARIA DE DESARROLLO SOCIAL', NULL),
(33, '308-DIRECCION DE CULTURA Y TURISMO', NULL),
(34, '503-DIRECCION DE PARQUES Y PASEOS', NULL),
(35, '305-DIRECCION DE DESARROLLO SOCIAL', NULL),
(36, '306-DIRECCION DE LA JUVENTUD', NULL),
(37, '401-SECRETARIA DE ECONOMIA', NULL),
(38, '301-SECRETARIA DE GOBIERNO', NULL),
(39, '313-SUB SECRETARIA DE CULTURA, TURISMO Y DEPORTE', NULL),
(40, '512-SUB SECRETARIA DE SERVICIOS PUBLICOS', NULL),
(41, '511-DIRECCION DE SERVICIOS URBANOS', NULL),
(42, '311-SUB SECRETARIA DE EDUCACION', NULL),
(43, '505-DIRECCION DE PLANEAMIENTO', NULL),
(44, '501-SECRETARIA DE PLANEAMIENTO, OBRAS Y SERVICIOS PUBLICOS', NULL),
(45, '303-TRIBUNAL DE FALTAS', NULL),
(46, '202-FISCALIA', 'Pepito Paz'),
(47, '310-AREA DE DEPORTES Y RECREACION SOCIAL', NULL),
(48, '402-CONTADURIA GENERAL', NULL),
(49, '403-TESORERIA GENERAL', NULL),
(50, '405-DIRECCION DE PRESUPUESTO', NULL),
(51, '406-DIRECCION DE COMPRAS, SUMINISTROS Y BIENES PATRIMONIALES', NULL),
(52, '407-SUB DIRECCION DE INFORMATICA', NULL),
(53, '410-OBLIGACION A CARGO DEL TESORO', NULL),
(54, '408-DIRECCION DE CATASTRO', NULL),
(55, '507-DIRECCION DE SUELO URBANO', NULL),
(56, '511/6-CENTRO OPERATIVO Nº 6', NULL),
(57, 'Prueba', 'Juan Prueba');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `_auditoria`
--

CREATE TABLE `_auditoria` (
  `id_auditoria` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `sql_texto` text COLLATE utf8_spanish_ci DEFAULT NULL,
  `id` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tag` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bien`
--
ALTER TABLE `bien`
  ADD PRIMARY KEY (`id_bien`);

--
-- Indices de la tabla `hoja_cargo`
--
ALTER TABLE `hoja_cargo`
  ADD PRIMARY KEY (`id_hoja_cargo`);

--
-- Indices de la tabla `hoja_cargo_item`
--
ALTER TABLE `hoja_cargo_item`
  ADD PRIMARY KEY (`id_hoja_cargo_item`);

--
-- Indices de la tabla `hoja_movimiento`
--
ALTER TABLE `hoja_movimiento`
  ADD PRIMARY KEY (`id_hoja_movimiento`);

--
-- Indices de la tabla `hoja_movimiento_item`
--
ALTER TABLE `hoja_movimiento_item`
  ADD PRIMARY KEY (`id_hoja_movimiento_item`);

--
-- Indices de la tabla `paramet`
--
ALTER TABLE `paramet`
  ADD PRIMARY KEY (`id_paramet`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id_proveedor`);

--
-- Indices de la tabla `tipo_alta`
--
ALTER TABLE `tipo_alta`
  ADD PRIMARY KEY (`id_tipo_alta`);

--
-- Indices de la tabla `tipo_baja`
--
ALTER TABLE `tipo_baja`
  ADD PRIMARY KEY (`id_tipo_baja`);

--
-- Indices de la tabla `tipo_bien`
--
ALTER TABLE `tipo_bien`
  ADD PRIMARY KEY (`id_tipo_bien`);

--
-- Indices de la tabla `uni_presu`
--
ALTER TABLE `uni_presu`
  ADD PRIMARY KEY (`id_uni_presu`);

--
-- Indices de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  ADD PRIMARY KEY (`id_auditoria`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bien`
--
ALTER TABLE `bien`
  MODIFY `id_bien` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `hoja_cargo`
--
ALTER TABLE `hoja_cargo`
  MODIFY `id_hoja_cargo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `hoja_cargo_item`
--
ALTER TABLE `hoja_cargo_item`
  MODIFY `id_hoja_cargo_item` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `hoja_movimiento`
--
ALTER TABLE `hoja_movimiento`
  MODIFY `id_hoja_movimiento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `hoja_movimiento_item`
--
ALTER TABLE `hoja_movimiento_item`
  MODIFY `id_hoja_movimiento_item` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `paramet`
--
ALTER TABLE `paramet`
  MODIFY `id_paramet` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `id_proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de la tabla `tipo_alta`
--
ALTER TABLE `tipo_alta`
  MODIFY `id_tipo_alta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tipo_baja`
--
ALTER TABLE `tipo_baja`
  MODIFY `id_tipo_baja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tipo_bien`
--
ALTER TABLE `tipo_bien`
  MODIFY `id_tipo_bien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `uni_presu`
--
ALTER TABLE `uni_presu`
  MODIFY `id_uni_presu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT de la tabla `_auditoria`
--
ALTER TABLE `_auditoria`
  MODIFY `id_auditoria` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
