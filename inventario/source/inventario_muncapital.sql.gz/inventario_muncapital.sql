-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 11-05-2019 a las 00:13:14
-- Versión del servidor: 10.1.31-MariaDB
-- Versión de PHP: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `inventario_muncapital`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `bien`
--

CREATE TABLE `bien` (
  `id_bien` int(11) NOT NULL,
  `id_hoja_cargo_item` int(11) DEFAULT NULL,
  `nro_serie` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `codigo_qr` text COLLATE utf8_spanish_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `bien`
--

INSERT INTO `bien` (`id_bien`, `id_hoja_cargo_item`, `nro_serie`, `codigo_qr`) VALUES
(1, 1, '1', 'compra - cobro - Paz Ramon - '),
(2, 1, '2', 'compra - cobro - Paz Ramon - '),
(3, 1, '3', 'compra - cobro - Paz Ramon - '),
(4, 1, '4', 'compra - cobro - Paz Ramon - '),
(5, 1, '5', 'compra - cobro - Paz Ramon - '),
(6, 2, '10', 'compra - cobro - Paz Ramon - '),
(7, 2, '11', 'compra - cobro - Paz Ramon - '),
(8, 2, '12', 'compra - cobro - Paz Ramon - '),
(13, 4, '6', 'compra - cobro - Paz Ramon - '),
(14, 4, '7', 'compra - cobro - Paz Ramon - '),
(15, 4, '8', 'compra - cobro - Paz Ramon - '),
(16, 4, '9', 'compra - cobro - Paz Ramon - '),
(17, 5, '234', 'gfgh - fghfgh - fgdfgdfg - '),
(18, 5, '23', 'gfgh - fghfgh - fgdfgdfg - '),
(19, 5, '234', 'gfgh - fghfgh - fgdfgdfg - '),
(20, 6, '', NULL),
(21, 6, '', NULL),
(22, 6, '', NULL),
(23, 6, '', NULL),
(24, 6, '', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_cargo`
--

CREATE TABLE `hoja_cargo` (
  `id_hoja_cargo` int(11) NOT NULL,
  `id_uni_presu` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL,
  `fecha_carga` datetime DEFAULT NULL,
  `fecha_verific` datetime DEFAULT NULL,
  `expte_compra` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `expte_cobro` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_factura` date DEFAULT NULL,
  `nro_factura` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario_carga` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario_verific` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` enum('C','V') COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `hoja_cargo`
--

INSERT INTO `hoja_cargo` (`id_hoja_cargo`, `id_uni_presu`, `id_proveedor`, `fecha_carga`, `fecha_verific`, `expte_compra`, `expte_cobro`, `fecha_factura`, `nro_factura`, `usuario_carga`, `usuario_verific`, `estado`) VALUES
(1, 1, 1, '2019-05-02 17:58:24', '2019-05-02 17:56:37', 'compra', 'cobro', '2019-05-10', '1234', 'rsantiagopaz', 'rsantiagopaz', 'C'),
(2, 2, 3, '2019-05-06 11:45:18', '2019-05-06 11:44:26', 'gfgh', 'fghfgh', '2019-05-07', '123', 'rsantiagopaz', 'rsantiagopaz', 'C'),
(3, 3, 3, NULL, '2019-05-06 12:10:56', 'jjjjj', 'jjjjj', '2019-05-15', 'jjjj', NULL, 'rsantiagopaz', 'V');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_cargo_item`
--

CREATE TABLE `hoja_cargo_item` (
  `id_hoja_cargo_item` int(11) NOT NULL,
  `id_hoja_cargo` int(11) DEFAULT NULL,
  `id_tipo_bien` int(11) DEFAULT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cantidad` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `hoja_cargo_item`
--

INSERT INTO `hoja_cargo_item` (`id_hoja_cargo_item`, `id_hoja_cargo`, `id_tipo_bien`, `descrip`, `cantidad`) VALUES
(1, 1, 1, 'Mouse', 5),
(2, 1, 2, 'Silla', 3),
(4, 1, 3, 'Paz', 4),
(5, 2, 3, 'dia', 3),
(6, 3, 1, 'jjjj', 5);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_movimiento`
--

CREATE TABLE `hoja_movimiento` (
  `id_hoja_movimiento` int(11) NOT NULL,
  `id_uni_presu` int(11) DEFAULT NULL,
  `fecha_movimiento` datetime DEFAULT NULL,
  `tipo_movimiento` enum('A','M','B') COLLATE utf8_spanish_ci DEFAULT NULL,
  `expte_autoriza` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `usuario_movimiento` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `hoja_movimiento`
--

INSERT INTO `hoja_movimiento` (`id_hoja_movimiento`, `id_uni_presu`, `fecha_movimiento`, `tipo_movimiento`, `expte_autoriza`, `usuario_movimiento`) VALUES
(1, 1, '2019-05-02 17:58:24', 'A', 'compra', 'rsantiagopaz'),
(2, NULL, '2019-05-03 05:10:04', 'B', 'fghghgh', 'rsantiagopaz'),
(3, 2, '2019-05-06 11:45:18', 'A', 'gfgh', 'rsantiagopaz');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `hoja_movimiento_item`
--

CREATE TABLE `hoja_movimiento_item` (
  `id_hoja_movimiento_item` int(11) NOT NULL,
  `id_hoja_movimiento` int(11) DEFAULT NULL,
  `id_bien` int(11) DEFAULT NULL,
  `guarda_custodia` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `hoja_movimiento_item`
--

INSERT INTO `hoja_movimiento_item` (`id_hoja_movimiento_item`, `id_hoja_movimiento`, `id_bien`, `guarda_custodia`) VALUES
(1, 1, 1, 'Paz Ramon'),
(2, 1, 2, 'Paz Ramon'),
(3, 1, 3, 'Paz Ramon'),
(4, 1, 4, 'Paz Ramon'),
(5, 1, 5, 'Paz Ramon'),
(6, 1, 13, 'Paz Ramon'),
(7, 1, 14, 'Paz Ramon'),
(8, 1, 15, 'Paz Ramon'),
(9, 1, 16, 'Paz Ramon'),
(10, 1, 6, 'Paz Ramon'),
(11, 1, 7, 'Paz Ramon'),
(12, 1, 8, 'Paz Ramon'),
(13, 2, 15, ''),
(14, 2, 7, ''),
(15, 3, 17, 'fgdfgdfg'),
(16, 3, 18, 'fgdfgdfg'),
(17, 3, 19, 'fgdfgdfg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedor`
--

CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL,
  `cuit` varchar(15) COLLATE utf8_spanish_ci DEFAULT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `contacto` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `proveedor`
--

INSERT INTO `proveedor` (`id_proveedor`, `cuit`, `descrip`, `contacto`) VALUES
(1, NULL, 'proveedor 1', NULL),
(2, NULL, 'proveedor 2', NULL),
(3, NULL, 'proveedor 3', NULL),
(4, NULL, 'proveedor 4', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_alta`
--

CREATE TABLE `tipo_alta` (
  `id_tipo_alta` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_alta`
--

INSERT INTO `tipo_alta` (`id_tipo_alta`, `descrip`) VALUES
(1, 'alta 1'),
(2, 'alta 2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_baja`
--

CREATE TABLE `tipo_baja` (
  `id_tipo_baja` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_baja`
--

INSERT INTO `tipo_baja` (`id_tipo_baja`, `descrip`) VALUES
(1, 'baja 1'),
(2, 'baja 2');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_bien`
--

CREATE TABLE `tipo_bien` (
  `id_tipo_bien` int(11) NOT NULL,
  `descrip` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `tipo_bien`
--

INSERT INTO `tipo_bien` (`id_tipo_bien`, `descrip`) VALUES
(1, 'Informatica'),
(2, 'tipo bien 2'),
(3, 'tipo bien 3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `uni_presu`
--

CREATE TABLE `uni_presu` (
  `id_uni_presu` int(11) NOT NULL,
  `descrip` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `uni_presu`
--

INSERT INTO `uni_presu` (`id_uni_presu`, `descrip`) VALUES
(1, '304-DIRECCION DEL NIÑO Y EL ADOLESCENTE'),
(2, 'ARBOLADO URBANO'),
(3, '511/0-CENTRO OPERATIVO Nº 0'),
(4, '511/1-CENTRO OPERATIVO Nº 1'),
(5, '511/2-CENTRO OPERATIVO Nº 2'),
(6, '511/3-CENTRO OPERATIVO Nº 3'),
(7, '511/4-CENTRO OPERATIVO Nº 4'),
(8, '511/5-CENTRO OPERATIVO Nº 5'),
(9, '510-DIRECCION DE CALIDAD DE VIDA'),
(10, '509-SUB DIRECCION DE CEMENTERIO'),
(11, '702-SUB DIRECCION DE CEREMONIAL Y PROTOCOLO'),
(12, 'CIC CAMPO CONTRERAS'),
(13, '701-SECRETARIA DE COORDINACION DE GABINETE'),
(14, '309-SUB DIRECCION DE DEFENSA CIVIL'),
(15, '901-DEFENSORIA DEL PUEBLO'),
(16, '504-DIRECCIÓN DE ELECTRICIDAD Y ALUMBRADO PUBLICO'),
(17, '801-TRIBUNAL DE CUENTAS'),
(18, '404-DIRECCIÓN DE RENTAS'),
(19, '508-DIRECCION DE TRANSITO Y TRANSPORTE'),
(20, '511/7-CENTRO OPERATIVO Nº 7'),
(21, '511/8-CENTRO OPERATIVO Nº 8'),
(22, '513-SUB DIRECCION DE CONTROL Y GESTION URBANA'),
(23, '707-DIRECCION DE PERSONAL Y RECONOCIMIENTO MEDICO'),
(24, '307-DIRECCION DE EDUCACION'),
(25, '506-DIRECCIÓN DE ESTUDIOS Y PROYECTOS'),
(26, '302-DIRECCION DE SALUD'),
(27, 'AREA DE HABILITACIONES'),
(28, '704-AREA DE PERSONERIA JURIDICA Y RELACIONES DELIBERANTES'),
(29, '201-INTENDENCIA'),
(30, '703-SUB DIRECCION DE PRENSA'),
(31, '502-DIRECCION DE OBRAS PUBLICAS Y MANTENIMIENTO'),
(32, '312-SUB SECRETARIA DE DESARROLLO SOCIAL'),
(33, '308-DIRECCION DE CULTURA Y TURISMO'),
(34, '503-DIRECCION DE PARQUES Y PASEOS'),
(35, '305-DIRECCION DE DESARROLLO SOCIAL'),
(36, '306-DIRECCION DE LA JUVENTUD'),
(37, '401-SECRETARIA DE ECONOMIA'),
(38, '301-SECRETARIA DE GOBIERNO'),
(39, '313-SUB SECRETARIA DE CULTURA, TURISMO Y DEPORTE'),
(40, '512-SUB SECRETARIA DE SERVICIOS PUBLICOS'),
(41, '511-DIRECCION DE SERVICIOS URBANOS'),
(42, '311-SUB SECRETARIA DE EDUCACION'),
(43, '505-DIRECCION DE PLANEAMIENTO'),
(44, '501-SECRETARIA DE PLANEAMIENTO, OBRAS Y SERVICIOS PUBLICOS'),
(45, '303-TRIBUNAL DE FALTAS'),
(46, '202-FISCALIA'),
(47, '310-AREA DE DEPORTES Y RECREACION SOCIAL'),
(48, '402-CONTADURIA GENERAL'),
(49, '403-TESORERIA GENERAL'),
(50, '405-DIRECCION DE PRESUPUESTO'),
(51, '406-DIRECCION DE COMPRAS, SUMINISTROS Y BIENES PATRIMONIALES'),
(52, '407-SUB DIRECCION DE INFORMATICA'),
(53, '410-OBLIGACION A CARGO DEL TESORO'),
(54, '408-DIRECCION DE CATASTRO'),
(55, '507-DIRECCION DE SUELO URBANO'),
(56, '511/6-CENTRO OPERATIVO Nº 6');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `bien`
--
ALTER TABLE `bien`
  ADD PRIMARY KEY (`id_bien`);

--
-- Indices de la tabla `hoja_cargo`
--
ALTER TABLE `hoja_cargo`
  ADD PRIMARY KEY (`id_hoja_cargo`);

--
-- Indices de la tabla `hoja_cargo_item`
--
ALTER TABLE `hoja_cargo_item`
  ADD PRIMARY KEY (`id_hoja_cargo_item`);

--
-- Indices de la tabla `hoja_movimiento`
--
ALTER TABLE `hoja_movimiento`
  ADD PRIMARY KEY (`id_hoja_movimiento`);

--
-- Indices de la tabla `hoja_movimiento_item`
--
ALTER TABLE `hoja_movimiento_item`
  ADD PRIMARY KEY (`id_hoja_movimiento_item`);

--
-- Indices de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  ADD PRIMARY KEY (`id_proveedor`);

--
-- Indices de la tabla `tipo_alta`
--
ALTER TABLE `tipo_alta`
  ADD PRIMARY KEY (`id_tipo_alta`);

--
-- Indices de la tabla `tipo_baja`
--
ALTER TABLE `tipo_baja`
  ADD PRIMARY KEY (`id_tipo_baja`);

--
-- Indices de la tabla `tipo_bien`
--
ALTER TABLE `tipo_bien`
  ADD PRIMARY KEY (`id_tipo_bien`);

--
-- Indices de la tabla `uni_presu`
--
ALTER TABLE `uni_presu`
  ADD PRIMARY KEY (`id_uni_presu`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `bien`
--
ALTER TABLE `bien`
  MODIFY `id_bien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `hoja_cargo`
--
ALTER TABLE `hoja_cargo`
  MODIFY `id_hoja_cargo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `hoja_cargo_item`
--
ALTER TABLE `hoja_cargo_item`
  MODIFY `id_hoja_cargo_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `hoja_movimiento`
--
ALTER TABLE `hoja_movimiento`
  MODIFY `id_hoja_movimiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `hoja_movimiento_item`
--
ALTER TABLE `hoja_movimiento_item`
  MODIFY `id_hoja_movimiento_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de la tabla `proveedor`
--
ALTER TABLE `proveedor`
  MODIFY `id_proveedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `tipo_alta`
--
ALTER TABLE `tipo_alta`
  MODIFY `id_tipo_alta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tipo_baja`
--
ALTER TABLE `tipo_baja`
  MODIFY `id_tipo_baja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tipo_bien`
--
ALTER TABLE `tipo_bien`
  MODIFY `id_tipo_bien` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `uni_presu`
--
ALTER TABLE `uni_presu`
  MODIFY `id_uni_presu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
